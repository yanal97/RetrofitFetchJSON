package com.example.retrofitrecyclerview;

import java.util.List;

public class ProductsList {

    private List<ProductsList.Sheets> ProductList;

    public ProductsList(List<Sheets> productList) {
        ProductList = productList;
    }

    public List<Sheets> getProductList() {
        return ProductList;
    }

    public class Sheets{

        private Double MaterialID;
        private String ChemicalName;
        private String HSCode;
        private String CASNo;
        private String UnNo;


        public Sheets(Double materialID, String chemicalName, String HSCode, String CASNo, String unNo) {
            MaterialID = materialID;
            ChemicalName = chemicalName;
            this.HSCode = HSCode;
            this.CASNo = CASNo;
            UnNo = unNo;
        }

        public Double getMaterialID() {
            return MaterialID;
        }

        public String getChemicalName() {
            return ChemicalName;
        }

        public String getHSCode() {
            return HSCode;
        }

        public String getCASNo() {
            return CASNo;
        }

        public String getUnNo() {
            return UnNo;
        }
    }


}
