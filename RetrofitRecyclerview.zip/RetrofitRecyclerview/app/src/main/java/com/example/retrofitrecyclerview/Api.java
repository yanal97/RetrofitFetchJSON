package com.example.retrofitrecyclerview;

import retrofit2.Call;
import retrofit2.http.GET;

public interface Api {

    String BASE_URL = "http://tataba3.com/";
    @GET("testjson.txt")
    Call<ProductsList> getSheets();
}
